CSCI5211 Project 1 - Labeled xGTracker Dataset
Created: 2026-11-06 (America/Chicago)

This dataset is a copied and reorganized version of the original xGTracker
export. The original source directory was not modified.

Contents
--------
Four experiment groups contain the three main loops plus any required retests:

  Home_Stationary       3 loops + 1 retest
  Home_Walking          3 loops + 3 retest sessions
  Alumni_Stationary     3 loops + 1 retest
  Alumni_Walking        3 loops + 1 retest

Each session folder is labeled with its role and original timestamp. Each test
folder is renamed according to its actual SessionManifest parameters and/or the
contents of its raw CSV or JSON log. The raw log filenames and file contents are
unchanged.

Examples
--------
  Video_Streaming__BOLA
  Video_Streaming__Throughput
  iPerf__TCP_Downlink__8_Streams
  Ping__Spain__130.206.13.20
  Web_Browsing__umn.edu__Cold_and_Warm
  File_Download__100MB__4_Connections__Repeat_2
  Video_Uplink__H264__Original_Card_1__1920x1080_30FPS

Video Uplink note
-----------------
The inspected VideoUpLink_log.csv files report H264 for both original uplink
card numbers. They are therefore labeled by the actual codec (H264) and retain
their original card number for traceability. H265 is not included in this
dataset and remains pending because of the reported server-capability issue.

Manifests
---------
  Session_Selection.csv  - the 18 included sessions and their loop/retest roles
  Folder_Name_Map.csv    - original test folder -> descriptive test folder
  H265_PENDING.txt       - explicit reminder that H265 has not been collected

No original raw file was renamed or edited.
