CSCI 5211 - Selected Retests from 2026-11-10

This is a copied and reorganized subset of the source export:
  xGTracker (1).zip

The original ZIP and all extracted source sessions were left unchanged.

Included structure
------------------
  Home_Stationary      3 complete loops
  Home_Walking         3 complete loops
  Alumni_Stationary    3 complete loops
  Alumni_Walking       3 complete loops

Strict validity requirement for every included loop
---------------------------------------------------
  - 8 of 8 File Download logs end with COMPLETED.
  - bytesDownloaded exactly equals FileSize.
  - lifecycleInfo says Download completed.
  - The H265 Video Uplink log reaches Progress=100 and Status=COMPLETED.
  - The H265 Video Uplink records nonzero Bytes Sent.

File Download configurations in every included loop
---------------------------------------------------
  File_Download_1: 100MB, 1 connection
  File_Download_2: 100MB, 4 connections
  File_Download_3: 512MB, 1 connection
  File_Download_4: 512MB, 4 connections
  File_Download_5: 1GB,   1 connection
  File_Download_6: 1GB,   4 connections
  File_Download_7: 2GB,   1 connection
  File_Download_8: 2GB,   4 connections

Video Uplink configuration
--------------------------
  Codec: H265
  Duration: 60 seconds
  Resolution: 1280x720 configured in the card
  Frame rate: 30 FPS
  Server: 18.191.141.219

Excluded sessions
-----------------
See Excluded_Failed_or_Partial_Sessions.csv. Three restart/partial sessions were
excluded; their raw data remains in the source ZIP.

Supporting manifests
--------------------
  Session_Selection_and_Validation.csv
  Test_Configuration_Map.csv
  Excluded_Failed_or_Partial_Sessions.csv
  Copy_Verification.csv
